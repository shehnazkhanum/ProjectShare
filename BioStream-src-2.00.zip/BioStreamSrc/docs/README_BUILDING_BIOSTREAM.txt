BUILD NOTES
In order to build BioStream, you will need the following tools in your classpath:

Windows-based systems:
- ant 1.6.1+ (http://ant.apache.org)
- makensis (http://nsis.sourceforge.net), this creates the executable used for installation.

Unix-based systems:
- ant 1.6.1+ (http://ant.apache.org)


BUILDING BIOSTREAM USING THE ANT SCRIPTS IN THE $BIOSTREAM_HOME/build DIRECTORY
There are two main build scripts: buildWin32.xml and builUnix.xml. They both have similar targets, which are described below.
* init - Define properties and classpath. Check various conditions. Build necessary directories.
* compile - Compile java files in the distribution directory.
* jar - Jar the files in the distribution directory.
* dist - Build the distributable, but do not package it.
* distAndPackage - Package the distributable into an executable.
* execute - Try running it from the distribution base. This can not be done if the target distExecutable has been executed.
* executeNoDeps - Try running it without re-building it. This can not be done if the target distExecutable has been executed.
* clean - Delete the distribution files and directories.


BUILDING BIOSTREAM MANUALLY
Let's look at what the ant scripts in the $BIOSTREAM_HOME/build directory actually do.
1. First, ant copies files from the source to the distribution directory. The files will copied to $DIST_BASE with their respective paths preserved, unless specified otherwise.
- $BIOSTREAM_HOME/* - copies all files.
- $BIOSTREAM_HOME/bin/* - copies all files.
- $BIOSTREAM_HOME/bin/com/** - copies all files and directories.
- $BIOSTREAM_HOME/bin/HelpSystem/** - copies all files.
- $BIOSTREAM_HOME/bin/images/** - copies all files.
- $BIOSTREAM_HOME/bin/templates/ImportTemplates/** - copies all files.
- $BIOSTREAM_HOME/bin/templates/ReportTemplates/** - copies all files.
- $BIOSTREAM_HOME/bin/templates/ToolTemplates/* - copies all files, but not subdirectories
- $BIOSTREAM_HOME/bin/templates/ToolTemplates/win32/* - if building for Windows, copies all files in the "win32" directory to $DIST_BASE/bin/templates/ToolTemplates.
- $BIOSTREAM_HOME/bin/templates/ToolTemplates/linux/* - if building for Linux, copies all files in the "linux" directory to $DIST_BASE/bin/templates/ToolTemplates.
- $BIOSTREAM_HOME/bin/templates/WebsiteTemplates/** - copies all files.
- $BIOSTREAM_HOME/bin/tools/ - copies import_List, report_List and website_List.
- $BIOSTREAM_HOME/bin/tools/win32/** - if building for Windows, then copies all files to $DIST_BASE/bin/tools.
- $BIOSTREAM_HOME/bin/tools/linux/** - if building for Linux, then copies all files to $DIST_BASE/bin/tools.
- $BIOSTREAM_HOME/bin/tools/any_os - copies all files to $DIST_BASE/bin/tools.
- $BIOSTREAM_HOME/build - does NOT copy this directory.
- $BIOSTREAM_HOME/build/win32/BioStreamInstaller.nsi - if building for Windows, copied to $DIST_BASE/.. (the directory above $DIST_BASE).
- $BIOSTREAM_HOME/build/unix/install_biostream.sh - if building for Linux, copied to $DIST_BASE.
- $BIOSTREAM_HOME/data/** - copies this directory.
- $BIOSTREAM_HOME/docs/** - copies all files and directories.
- $BIOSTREAM_HOME/legal/** - copies all files and directories.
- $BIOSTREAM_HOME/lib - if building for Windows, then FSDatabaseDLL.dll is copied.
- $BIOSTREAM_HOME/lib - if building for Linux, then libFSDatabaseDll.so is copied.

2. Then, ant compiles and jars the BioStream\bin\com files and builds any tools that need to built.
- $DIST_BASE/bin/*.java - all java files are compiled and the java files are deleted.
- $DIST_BASE/bin/com/** - all java files are compiled and then jarred into BioStream.jar. The "com" directory is then deleted.
- $DIST_BASE/bin/tools/usd - there are three jar files that are created from the "usd" directory: NcbiBlast.jar, NcbiBlastRetrieveRid.jar and NcbiFetch.jar. Reference the *Ncbi*.xml ant scripts in the $BIOSTREAM_HOME/build/any_os directory to see how these jar files are built. The "usd" directory is then deleted.

3. After $DIST_BASE is prepared, then the files are packaged into an installation file.
- If building for Windows, then NSIS 2.0 compiles and runs the $DIST_BASE/../*.nsi script to prepare the installation executable.
- If building for Linux, then $DIST_BASE is simply tarred and zipped into a *.tgz file.