You will need the following programs installed in order to RUN BioStream.

Windows-based systems:
- J2SE 1.4.2 or higher

Unix-based systems:
- J2SE 1.4.2 or higher
- Perl
