Date:           07/23/2004
Version:        20040723
Description:    BioStream-1.0.exe - This version of BioStream is a full
                release.  

-------------------------------------------------------------------------------
Part I:         Installation, Execution, and Removal         
-------------------------------------------------------------------------------

To install BioStream, launch the BioStream-x.x.exe file, (where x.x denotes the
application version), and follow the onscreen instructions.   The application
requires Java JRE 1.3 or newer in order to run.  The installation will proceed
without a suitable JRE installed; however, the application will generate an
error when executed.  

The application launches from the BioStream folder on the Window's Start
Menu.  The base distribution includes a sample Genebank Sequence file that
loads as follows:

    1.	Select Import from the menu bar.
    2.	Highlight Create and select Genebank.
    3.	Enter a name for the new database and click Create.
    4.	Select the small.seq file and click Import.

BioStream's uninstaller launches from either the BioStream folder on the
Window's Start Menu or the Add/Remove Program applet in the Control Panel.
The uninstallation of the application does not remove the data files created by
the application.   


-------------------------------------------------------------------------------
Part II:        Complete File Listing
-------------------------------------------------------------------------------

BioStream/ReadMe.txt

BioStream/bin/BioStream.jar
BioStream/bin/GBMetaFile.mta
BioStream/bin/genbank.asn
BioStream/bin/PDB.asn
BioStream/bin/ProjectManager.asn
BioStream/bin/rebase.txt
BioStream/bin/tiny1.top
BioStream/bin/Tiny.xml

BioStream/bin/HelpSystem/appendix.htm
BioStream/bin/HelpSystem/biologo.gif
BioStream/bin/HelpSystem/biosmall.gif
BioStream/bin/HelpSystem/fig11.gif
BioStream/bin/HelpSystem/fig12.gif
BioStream/bin/HelpSystem/fig13.gif
BioStream/bin/HelpSystem/fig14.gif
BioStream/bin/HelpSystem/fig15.gif
BioStream/bin/HelpSystem/fig16.gif
BioStream/bin/HelpSystem/fig1a.gif
BioStream/bin/HelpSystem/fig1b.gif
BioStream/bin/HelpSystem/fig1c.gif
BioStream/bin/HelpSystem/fig1d.gif
BioStream/bin/HelpSystem/fig1e.gif
BioStream/bin/HelpSystem/fig2.gif
BioStream/bin/HelpSystem/fig3.gif
BioStream/bin/HelpSystem/fig4.gif
BioStream/bin/HelpSystem/fig5.gif
BioStream/bin/HelpSystem/fig6.gif
BioStream/bin/HelpSystem/fig7.gif
BioStream/bin/HelpSystem/fig8.gif
BioStream/bin/HelpSystem/fig9.gif
BioStream/bin/HelpSystem/Image1.gif
BioStream/bin/HelpSystem/index.htm
BioStream/bin/HelpSystem/Part10.htm
BioStream/bin/HelpSystem/Part11.htm
BioStream/bin/HelpSystem/Part12.htm
BioStream/bin/HelpSystem/Part13.htm
BioStream/bin/HelpSystem/Part14.htm
BioStream/bin/HelpSystem/Part15.htm
BioStream/bin/HelpSystem/Part1.htm
BioStream/bin/HelpSystem/part2.htm
BioStream/bin/HelpSystem/part3.htm
BioStream/bin/HelpSystem/Part4.htm
BioStream/bin/HelpSystem/Part5.htm
BioStream/bin/HelpSystem/Part6.htm
BioStream/bin/HelpSystem/Part7.htm
BioStream/bin/HelpSystem/Part8.htm
BioStream/bin/HelpSystem/Part9.htm
BioStream/bin/HelpSystem/QueryActive.gif
BioStream/bin/HelpSystem/RetrieveActive.gif
BioStream/bin/HelpSystem/SequenceActive.gif
BioStream/bin/HelpSystem/space10.gif
BioStream/bin/HelpSystem/space20.gif
BioStream/bin/HelpSystem/space50.gif
BioStream/bin/HelpSystem/Table2a.gif
BioStream/bin/HelpSystem/Table2b.gif
BioStream/bin/HelpSystem/Table2c.gif
BioStream/bin/HelpSystem/Table2d.gif
BioStream/bin/HelpSystem/Table2e.gif
BioStream/bin/HelpSystem/Table2f.gif
BioStream/bin/HelpSystem/Table2g.gif
BioStream/bin/HelpSystem/Table2h.gif
BioStream/bin/HelpSystem/Table2j.gif
BioStream/bin/HelpSystem/Table2k.gif
BioStream/bin/HelpSystem/Table2l.gif
BioStream/bin/HelpSystem/Table2m.gif
BioStream/bin/HelpSystem/Table2n.gif
BioStream/bin/HelpSystem/Table2o.gif
BioStream/bin/HelpSystem/Table2p.gif
BioStream/bin/HelpSystem/Table2q.gif
BioStream/bin/HelpSystem/Table2r.gif
BioStream/bin/HelpSystem/Table2s.gif
BioStream/bin/HelpSystem/Table2t.gif
BioStream/bin/HelpSystem/Table2u.gif
BioStream/bin/HelpSystem/Table2v.gif
BioStream/bin/HelpSystem/Table2w.gif
BioStream/bin/HelpSystem/Table2x.gif
BioStream/bin/HelpSystem/Thumbs.db
BioStream/bin/HelpSystem/ToolsActive.gif
BioStream/bin/HelpSystem/ViewEditActive.gif

BioStream/bin/images/alle.gif
BioStream/bin/images/AnalyzerActive.gif
BioStream/bin/images/AnalyzerClick.gif
BioStream/bin/images/AnalyzerDisable.gif
BioStream/bin/images/AnalyzerDown.gif
BioStream/bin/images/AnalyzerPanel.gif
BioStream/bin/images/AnalyzerUp.gif
BioStream/bin/images/BioIcon.gif
BioStream/bin/images/biostream_font.properties
BioStream/bin/images/BioStream.ico
BioStream/bin/images/BioWave-Frame.gif
BioStream/bin/images/BioWave.gif
BioStream/bin/images/Boolean.gif
BioStream/bin/images/CleanDataActive.gif
BioStream/bin/images/CleanDataClick.gif
BioStream/bin/images/CleanDataDisable.gif
BioStream/bin/images/CleanDataDown.gif
BioStream/bin/images/CleanDataPanel.gif
BioStream/bin/images/CleanDataUp.gif
BioStream/bin/images/Copy of feature_List
BioStream/bin/images/DataActive.gif
BioStream/bin/images/DataClick.gif
BioStream/bin/images/DataDisable.gif
BioStream/bin/images/DataDown.gif
BioStream/bin/images/DataIcon.gif
BioStream/bin/images/DataPanel.gif
BioStream/bin/images/DataUp.gif
BioStream/bin/images/dna.gif
BioStream/bin/images/EnumerationIcon.gif
BioStream/bin/images/ExportsIcon.gif
BioStream/bin/images/feature_List
BioStream/bin/images/ftp_site_List
BioStream/bin/images/Integer.gif
BioStream/bin/images/IntegerIcon.gif
BioStream/bin/images/IntegerImage.jpg
BioStream/bin/images/NASequenceIcon.gif
BioStream/bin/images/Object1Icon.gif
BioStream/bin/images/ObjectIcon.gif
BioStream/bin/images/ProjectIcon.gif
BioStream/bin/images/ProjectMgrActive.gif
BioStream/bin/images/ProjectMgrClick.gif
BioStream/bin/images/ProjectMgrDisable.gif
BioStream/bin/images/ProjectMgrDisplay.gif
BioStream/bin/images/ProjectMgrDown.gif
BioStream/bin/images/ProjectMgrPanel.gif
BioStream/bin/images/ProjectMgrUp.gif
BioStream/bin/images/PropertiesIcon.gif
BioStream/bin/images/qualifier_List
BioStream/bin/images/QueryActive.gif
BioStream/bin/images/QueryClick.gif
BioStream/bin/images/QueryDisable.gif
BioStream/bin/images/QueryDown.gif
BioStream/bin/images/QueryIcon.gif
BioStream/bin/images/QueryPanel.gif
BioStream/bin/images/QueryUp.gif
BioStream/bin/images/Real.gif
BioStream/bin/images/RealIcon.gif
BioStream/bin/images/ReferenceLibraryIcon.gif
BioStream/bin/images/ReportsActive.gif
BioStream/bin/images/ReportsClick.gif
BioStream/bin/images/ReportsDisable.gif
BioStream/bin/images/ReportsDown.gif
BioStream/bin/images/ReportsIcon.gif
BioStream/bin/images/ReportsPanel.gif
BioStream/bin/images/ReportsUp.gif
BioStream/bin/images/RetrieveActive.gif
BioStream/bin/images/RetrieveClick.gif
BioStream/bin/images/RetrieveDisable.gif
BioStream/bin/images/RetrieveDown.gif
BioStream/bin/images/RetrievePanel.gif
BioStream/bin/images/RetrieveSmall.gif
BioStream/bin/images/RetrieveUp.gif
BioStream/bin/images/ScriptIcon.gif
BioStream/bin/images/SequenceActive.gif
BioStream/bin/images/SequenceClick.gif
BioStream/bin/images/SequenceDisable.gif
BioStream/bin/images/SequenceDown.gif
BioStream/bin/images/SequencePanel.gif
BioStream/bin/images/SequenceUp.gif
BioStream/bin/images/StringIcon.gif
BioStream/bin/images/Thumbs.db
BioStream/bin/images/ToolsActive.gif
BioStream/bin/images/ToolsClick.gif
BioStream/bin/images/ToolsDisable.gif
BioStream/bin/images/ToolsDown.gif
BioStream/bin/images/ToolsIcon.gif
BioStream/bin/images/ToolsPanel.gif
BioStream/bin/images/ToolsUp.gif
BioStream/bin/images/ViewEditActive.gif
BioStream/bin/images/ViewEditClick.gif
BioStream/bin/images/ViewEditDisable.gif
BioStream/bin/images/ViewEditDown.gif
BioStream/bin/images/ViewEditPanel.gif
BioStream/bin/images/ViewEditUp.gif
BioStream/bin/images/ViewIcon.gif
BioStream/bin/images/WebIcon.gif


BioStream/bin/templates/ImportTemplates/Genbank.dtd
BioStream/bin/templates/ImportTemplates/PDB.dtd

BioStream/bin/templates/ReportTemplates/FASTA.dtd
BioStream/bin/templates/ReportTemplates/Genbank_Nucleotide.dtd
BioStream/bin/templates/ReportTemplates/Genbank_Protein.dtd
BioStream/bin/templates/ReportTemplates/GI_Locus_Tag.dtd
BioStream/bin/templates/ReportTemplates/PDB.dtd

BioStream/bin/templates/ToolTemplates/BlastTemplate.dtd
BioStream/bin/templates/ToolTemplates/Clustalx.dtd
BioStream/bin/templates/ToolTemplates/FormatdbTemplate.dtd
BioStream/bin/templates/ToolTemplates/GeneSeqerTry.dtd
BioStream/bin/templates/ToolTemplates/NCBIDownloadFromGI1.dtd
BioStream/bin/templates/ToolTemplates/NCBIDownloadFromGI.dtd
BioStream/bin/templates/ToolTemplates/NCBIFetchTemplate.dtd

BioStream/bin/templates/WebsiteTemplates/NCBITemplate.dtd

BioStream/bin/tools/blastall.exe
BioStream/bin/tools/carol.seq
BioStream/bin/tools/clustalx.exe
BioStream/bin/tools/compress.exe
BioStream/bin/tools/Fetch.jar
BioStream/bin/tools/formatdb.exe
BioStream/bin/tools/giNew.exe
BioStream/bin/tools/giNew.pl
BioStream/bin/tools/gi.pl
BioStream/bin/tools/gunzip.exe
BioStream/bin/tools/GZIP386.EXE
BioStream/bin/tools/GZIP.EXE
BioStream/bin/tools/import_List
BioStream/bin/tools/pdb1a03.ent
BioStream/bin/tools/rasmol.hlp
BioStream/bin/tools/report_List
BioStream/bin/tools/tool_List
BioStream/bin/tools/website_List
BioStream/bin/tools/win32gnu.dll
BioStream/bin/tools/xraswin.exe

BioStream/Launcher/BioStream.exe
BioStream/Launcher/FSDatabaseDLL.dll
BioStream/Launcher/small.seq


-------------------------------------------------------------------------------
Part III:       General Information
-------------------------------------------------------------------------------			

BioStream is a complete, open bioinformatics workstation.  It operates as a
standalone application on a local system.  It is initially being released for
both Windows and Linux platforms.

BioStream is organized around three key concepts, or metaphors. 

- Managers as an Organizational Framework
Basic operations of the system - data, Web retrievals, queries, reports, tools,
etc. - are organized around the concepts of "Managers."  These Managers present
a unified operational view of the system, hopefully replicable across
functional areas, each supported by persistent scripts created while working
with the GUI(graphical user interface), for sharing configurations with others
or driving the system in a non-GUI manner.  The individual Managers are
themselves managed by an overall Project Manager.

- Use of Field Streams for Object and Data Management
Field streams, which are extensible and hierarchical as well as providing
powerful and arbitrary data relationships, are the internal organizational and
management framework for the system.  The "objects" within BioStream, nested
from the Project Manager on down to the lowest level of atomic data or
properties, fit beautifully within this field stream framework.

- The Tree Metaphor for GUI Management and Manipulation
The central visual metaphor within the system is a greatly enhanced tree
control that can reflect all of the nested capabilities and object tagging
inherent with field streams.

Field streams are the overall organizational framework for storing and managing
both the data and the graphical user objects and functionality within
BioStream.  Field streams are a unique way to store and view data that offer
the advantages of extensibility, direct (fast) access, and maintenance of data
representations in the complete native schema (relational, object-oriented,
ACeDB, etc.) of any source dataset.

Field streams support any arbitrary data relation including one-to-one,
one-to-many, many-to-one, and choice.  Once source data is converted to field
streams, a layer of "umbrella" field streams over multiple datasets provides
the metadata management and a single representation for querying and
manipulating all of the constituent sources.  Field streams can store most
primitive data types such as integers, strings (sequences), reals, etc.

-------------------------------------------------------------------------------
Part IV:            Update Description 
-------------------------------------------------------------------------------
Release 07/23/2004

1.  Initial Release

-------------------------------------------------------------------------------
Part V:             Bug Fixes and Minor Changes 
-------------------------------------------------------------------------------
None to Date
-------------------------------------------------------------------------------
Part VI:            Changes Still Pending
-------------------------------------------------------------------------------
None to Date